x = 4
b = 2
if x > b 
  print("x is greater than b")